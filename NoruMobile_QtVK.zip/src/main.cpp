
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QByteArray>

int main(int argc, char *argv[]) {
    qputenv("QT_IM_MODULE", QByteArray("qtvirtualkeyboard"));
    QGuiApplication app(argc, argv);
    app.setApplicationDisplayName(QStringLiteral("Noru mobile"));

    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/Noru/qml/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated, &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl) QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);
    return app.exec();
}
